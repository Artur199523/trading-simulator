import {Provider} from "react-redux"
import React from 'react';
import './App.css';

import {store} from "./store";
import Simulator from "./pages/Simulator";
import {SimulatorProvider} from "./layouts/providers";
import {SimulatorOptionsProvider} from "layouts/providers";
import {SimulatorToolsProvider} from "./layouts/providers/simulatorToolsProvider";

function App() {
    return (
        <Provider store={store}>
            <SimulatorOptionsProvider>
                <SimulatorProvider>
                    <SimulatorToolsProvider>
                        <Simulator/>
                    </SimulatorToolsProvider>
                </SimulatorProvider>
            </SimulatorOptionsProvider>
        </Provider>
    );
}

export default App;
