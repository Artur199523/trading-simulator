import React from "react";
import {HistoryItem} from "store/simulator/type";

export interface SimulatorProviderITF {
    children: React.ReactNode
}

export interface SimulatorContextITF {
    next: boolean
    isPlay: boolean,
    isStart: boolean,
    process: ProcessT,
    USDTBalance: number,
    currency: CurrencyT,
    interval: IntervalT,
    cryptoType: CryptoTypeT,
    tradingType: TradingType,
    currentCryptoData: HistoryItem | {},
    currentSpeed: CurrentSpeedT,
    currentCryptoBalance: number,
    setNext: (isNext: boolean) => void,
    setUSDTBalance: (USDT:number)=>void,
    setIsPlay: (isPlay: boolean) => void,
    setIsStart: (isStart: boolean) => void,
    setProcess: (process:ProcessT) => void,
    setInterval: (interval: IntervalT) => void,
    setCurrency: (currency: CurrencyT) => void,
    setCryptoType: (crypto: CryptoTypeT) => void,
    setCurrentCryptoData: (data:HistoryItem) => void,
    setTradingType: (trading:TradingType) => void,
    setCurrentSpeed: (speed: CurrentSpeedT) => void,
    setCurrentCryptoBalance: (crypto:number) => void
}

export interface SimulatorOptionsContextITF {
    currency: CurrencyT,
    interval: IntervalT,
    cryptoType: CryptoTypeT,
    setInterval: (interval: IntervalT) => void,
    setCurrency: (currency: CurrencyT) => void,
    setCryptoType: (crypto: CryptoTypeT) => void,
}

export interface SimulatorToolsContextITF {
    next: boolean
    isPlay: boolean,
    isStart: boolean,
    currentSpeed: CurrentSpeedT,
    setNext: (isNext: boolean) => void,
    setIsPlay: (isPlay: boolean) => void,
    setIsStart: (isStart: boolean) => void,
    setCurrentSpeed: (speed: CurrentSpeedT) => void,
}

export type IntervalT = "histominute"

export type CurrencyT = "USD" | "EUR"

export type CryptoTypeT = "ETH" | "BTC"

export type CurrentSpeedT = 1 | 3 | 10

export type TradingType = "spot" | "futures"

export type ProcessT = "buy" | "sell"