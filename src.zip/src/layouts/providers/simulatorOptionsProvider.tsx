import React, {createContext, useContext, useState,memo} from "react"
import {CryptoTypeT, CurrencyT, IntervalT, SimulatorOptionsContextITF, SimulatorProviderITF} from "./type";

const SimulatorOptionsContext = createContext<SimulatorOptionsContextITF>({
    setInterval: () => {},
    setCurrency: () => {},
    setCryptoType: () => {},
    currency: "USD",
    cryptoType: "ETH",
    interval: "histominute",
})
export const SimulatorOptionsProvider: React.FC<SimulatorProviderITF> = memo(({children}) => {
    const [interval, setInterval] = useState<IntervalT>("histominute")
    const [currency, setCurrency] = useState<CurrencyT>("USD")
    const [cryptoType, setCryptoType] = useState<CryptoTypeT>("ETH")

    return (
        <SimulatorOptionsContext.Provider value={{
            interval,
            currency,
            cryptoType,
            setInterval,
            setCurrency,
            setCryptoType
        }}>
            {children}
        </SimulatorOptionsContext.Provider>
    )
})

export const useSimulatorOptionsContext = () => useContext(SimulatorOptionsContext)