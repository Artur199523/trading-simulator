import React from "react";

export interface InputRangeITF {
    onChange: (e:React.ChangeEvent<HTMLInputElement>) => void
}