import React from "react";

const Futures:React.FC = () => {
    return(
        <div className="futures">

        </div>
    )
}

export default Futures