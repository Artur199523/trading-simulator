import React, {memo} from "react";

import {useSimulatorContext} from "layouts/providers";

import "./style.scss"

const Balance:React.FC = () => {
    const {process,USDTBalance,currentCryptoBalance,cryptoType} = useSimulatorContext()

    return (
        <div className="right-bar_balance">
            {process === "buy"
                ? <div className="spot_market_balance">Available: <span>{USDTBalance} USDT</span></div>
                : <div className="spot_market_balance">Available: <span>{currentCryptoBalance} {cryptoType}</span></div>
            }
        </div>
    )
}

export default memo(Balance)