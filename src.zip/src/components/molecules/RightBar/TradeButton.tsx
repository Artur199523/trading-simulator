import React from "react";
import classNames from "classnames";
import {useSimulatorContext} from "layouts/providers";

import "./style.scss"

const TradeButton: React.FC<any> = ({onClick}) => {
    const {process} = useSimulatorContext()

    const btnStyle = classNames('right-bar_trading-confirm-btn',{"active-buy": process === "buy"}, {"active-sell": process === "sell"})

    return (
        <button onClick={onClick} className={btnStyle}>{process === "buy" ? "BUY" : "SELL"}</button>
    )
}

export default TradeButton