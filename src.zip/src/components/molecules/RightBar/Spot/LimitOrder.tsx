import React from "react";

const LimitOrder:React.FC = () => {
    return(
        <div className="spot_limit-order">

        </div>
    )
}

export default LimitOrder