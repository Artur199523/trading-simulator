import React, {memo, useEffect, useState} from "react";

import {useSimulatorContext} from "layouts/providers";

import {Input, InputRange} from "components";
import TradeButton from "../TradeButton";

const Market: React.FC = () => {
    const {process} = useSimulatorContext()

    const [price, setPrice] = useState("")
    const [percent, setPercent] = useState(0)
    const [usdt, setUsdt] = useState("")

    useEffect(() => {
        setUsdt("")
    }, [process]);

    const tradeInMarket = () => {
        console.log(percent,usdt)
    }

    return (
        <div className="spot_market">
            <Input
                name="price"
                type="number"
                value={price}
                disabled={true}
                placeholder="Price"
                onChange={(e) => setPrice(e.target.value)}
            />
            <Input
                name="usdt"
                value={usdt}
                type="number"
                placeholder={process === "buy" ? "USDT" : "ETH"}
                onChange={(e) => setUsdt(e.target.value)}
            />
            <InputRange onChange={(e) => setPercent(e as any)}/>
            <TradeButton onClick={tradeInMarket}/>
        </div>
    )
}

export default memo(Market)